package org.stuq.androidui;

import io.appium.java_client.android.AndroidDriver;

import java.net.URL;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Quiz02 {
	private AndroidDriver<?> driver;	

	@BeforeClass
	@Parameters({ "udid","deviceName" })
	public void setUp(String udid, String deviceName) throws Exception {
		// set up appium
		/*File classpathRoot = new File(System.getProperty("user.dir"));
		File appDir = new File(classpathRoot, "apps");
		File app = new File(appDir, "HelloAndroid.apk");*/
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("deviceName","Google_Nexus_5X___6_0_0___API_23___1080x1920");
		capabilities.setCapability("udid", "192.168.154.101:5555");
		capabilities.setCapability("platformVersion", "4.4");
		// don't add this if apk installation is not necessary
		//capabilities.setCapability("app", app.getAbsolutePath());
		capabilities.setCapability("appPackage", "com.hujiang.normandy");
		// support Chinese
		capabilities.setCapability("unicodeKeyboard", "True");
		capabilities.setCapability("resetKeyboard", "True");
		// no need sign
		capabilities.setCapability("noSign", "True");
		capabilities.setCapability("appActivity", ".SplashActivity");
		capabilities.setCapability("noReset", "True");
		driver = new AndroidDriver(new URL("http://localhost:4723/wd/hub"),capabilities);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}

	@Test
	public void testLogin() throws InterruptedException {
		WebElement loginBtn = driver.findElementById("com.hujiang.normandy:id/login");
		loginBtn.click();
		Thread.sleep(3000);
        Set<String> context = driver.getContextHandles();
        for (String contextName : context) {
            System.out.println(contextName);

        }
        driver.context("WEBVIEW_com.hujiang.normandy");
        WebElement usernamebox = driver.findElementByXPath("//*[@id='hp-login-normal']/div[1]/input");
        usernamebox.clear();
        usernamebox.sendKeys("");
        WebElement pwdbox = driver.findElementByXPath("//*[@id='hp-login-normal']/div[3]/input");
        pwdbox.sendKeys("");
        WebElement loginbtn = driver.findElementByXPath("//*[@id='hp-login-normal']/button");
        loginbtn.click();
        driver.context("NATIVE_APP");
        String home_username = driver.findElementById("com.hujiang.normandy:id/home_username").getText();
        Assert.assertEquals(home_username, "");
        Thread.sleep(3000);
	}

	@AfterClass
	public void tearDown() throws Exception {
		driver.quit();
	}
}