package com.young.cucumber;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Search {
	public WebDriver driver;
	public String baseUrl;

	//初始化浏览器操作
	public void setUp() {
		driver = new FirefoxDriver();
		baseUrl = "http://www.so.com/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	//打开url
	public void open() {
		setUp();
		driver.get(baseUrl);
	}

	//查找cucumber是不是显示了
	public String find(String keyword) {
		String result = null;
		WebElement element = null;

		driver.findElement(By.name("q")).clear();
		driver.findElement(By.name("q")).sendKeys(keyword);
		driver.findElement(By.id("search-button")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		element = driver.findElement(By.id("first"));
		if (element.getText().contains("cucumber")) {
			result = "cucumber";
		}
		quit();
		return result;
	}

	//释放资源
	public void quit() {
		driver.quit();
	}
}