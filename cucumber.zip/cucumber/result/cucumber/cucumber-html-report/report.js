$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/young/cucumber/resources/search.feature");
formatter.feature({
  "id": "搜索",
  "description": "",
  "name": "搜索",
  "keyword": "Feature",
  "line": 1
});
formatter.background({
  "description": "",
  "name": "用户在 http://www.so.com/搜索cucumber信息",
  "keyword": "Background",
  "line": 2,
  "type": "background"
});
formatter.scenario({
  "id": "搜索;在360搜索上搜索cucumber",
  "description": "",
  "name": "在360搜索上搜索cucumber",
  "keyword": "Scenario",
  "line": 4,
  "type": "scenario"
});
formatter.step({
  "name": "用户打开http://www.so.com/",
  "keyword": "Given ",
  "line": 5
});
formatter.step({
  "name": "输入关键字：cucumber",
  "keyword": "When ",
  "line": 6
});
formatter.step({
  "name": "搜索结果：cucumber就会显示出来",
  "keyword": "Then ",
  "line": 7
});
formatter.match({
  "location": "SearchStepdefs.open()"
});
formatter.result({
  "duration": 11115181795,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "cucumber",
      "offset": 6
    }
  ],
  "location": "SearchStepdefs.input(String)"
});
formatter.result({
  "duration": 22167202920,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "cucumber",
      "offset": 5
    }
  ],
  "location": "SearchStepdefs.result(String)"
});
formatter.result({
  "duration": 2147777,
  "status": "passed"
});
});